import { redirect } from "next/navigation";
import { getSessionProfile } from "@/lib/auth";
import { createClient } from "@/lib/supabase/server";
import { isStaff, type Announcement } from "@/lib/types";
import AnnouncementComposer from "./AnnouncementComposer";

export const dynamic = "force-dynamic";

function visible(
  a: Announcement,
  dept: string | null,
  year: number | null,
  staff: boolean
) {
  if (staff) return true;
  if (a.audience_dept && a.audience_dept !== dept) return false;
  if (a.audience_year && a.audience_year !== year) return false;
  return true;
}

export default async function AnnouncementsPage() {
  const profile = await getSessionProfile();
  if (!profile) redirect("/login");

  const supabase = await createClient();
  const { data } = await supabase
    .from("announcements")
    .select("*, author:created_by(full_name)")
    .order("created_at", { ascending: false });

  const all = (data as Announcement[] | null) ?? [];
  const staff = isStaff(profile.role);
  const list = all.filter((a) => visible(a, profile.department, profile.year, staff));

  return (
    <div>
      <h1 className="text-xl font-bold">Announcements</h1>
      <p className="mb-5 mt-1 text-sm text-slate-400">News and notices from the institute.</p>

      {staff && <AnnouncementComposer />}

      <div className="space-y-3">
        {list.length === 0 && (
          <p className="text-sm text-slate-500">No announcements yet.</p>
        )}
        {list.map((a) => (
          <div key={a.id} className="rounded-2xl border border-white/10 bg-white/5 p-4">
            <div className="flex items-center justify-between gap-3">
              <h3 className="font-semibold">{a.title}</h3>
              <span className="text-xs text-slate-500">
                {new Date(a.created_at).toLocaleDateString()}
              </span>
            </div>
            <p className="mt-1 whitespace-pre-wrap text-sm text-slate-300">{a.body}</p>
            <div className="mt-2 text-xs text-slate-500">
              {a.author?.full_name ?? "Staff"}
              {" · "}
              {a.audience_dept ? a.audience_dept : "Whole institute"}
              {a.audience_year ? ` · Year ${a.audience_year}` : ""}
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
