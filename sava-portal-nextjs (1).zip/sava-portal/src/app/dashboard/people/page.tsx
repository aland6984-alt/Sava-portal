import { requireRole } from "@/lib/auth";
import { createClient } from "@/lib/supabase/server";
import type { Profile } from "@/lib/types";
import PeopleManager from "./PeopleManager";

export const dynamic = "force-dynamic";

export default async function PeoplePage() {
  await requireRole(["admin", "super_admin"]);
  const supabase = await createClient();
  const { data } = await supabase
    .from("profiles")
    .select("*")
    .order("created_at", { ascending: true });

  return (
    <div>
      <h1 className="text-xl font-bold">People</h1>
      <p className="mb-5 mt-1 text-sm text-slate-400">
        All accounts at the institute. You can update roles and classes.
      </p>
      <PeopleManager initial={(data as Profile[]) ?? []} />
    </div>
  );
}
