import { requireRole } from "@/lib/auth";
import { createClient } from "@/lib/supabase/server";
import type { Subject } from "@/lib/grades";
import SubjectsManager from "./SubjectsManager";

export const dynamic = "force-dynamic";

export default async function SubjectsPage() {
  await requireRole(["admin", "super_admin", "teacher"]);
  const supabase = await createClient();
  const { data } = await supabase
    .from("subjects")
    .select("*")
    .order("department")
    .order("year")
    .order("name");

  return (
    <div>
      <h1 className="text-xl font-bold">Subjects</h1>
      <p className="mb-5 mt-1 text-sm text-slate-400">
        Create subjects, then open one to enter student grades.
      </p>
      <SubjectsManager initial={(data as Subject[]) ?? []} />
    </div>
  );
}
