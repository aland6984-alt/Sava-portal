import { requireRole } from "@/lib/auth";
import DashCard from "@/components/DashCard";

export default async function AdminDashboard() {
  const profile = await requireRole(["admin", "super_admin"]);
  return (
    <div>
      <h1 className="text-2xl font-bold">Admin Dashboard</h1>
      <p className="mt-1 text-slate-400">Welcome, {profile.full_name ?? "there"}.</p>
      <div className="mt-6 grid gap-3 sm:grid-cols-2">
        <DashCard href="/dashboard/announcements" icon="📣" title="Announcements" desc="Post news and notices." />
        <DashCard href="/dashboard/subjects" icon="📚" title="Subjects & grades" desc="Create subjects and enter grades." />
        <DashCard href="/dashboard/people" icon="🗂️" title="People" desc="Manage students, teachers and roles." />
        <DashCard href="/dashboard/profile" icon="👤" title="My profile" desc="Update your personal details." />
      </div>
      <p className="mt-6 text-xs text-slate-500">More modules (attendance, payments, messaging) are being added step by step.</p>
    </div>
  );
}
