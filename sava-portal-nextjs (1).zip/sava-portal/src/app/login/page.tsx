"use client";

import { useState } from "react";
import Link from "next/link";
import { useRouter } from "next/navigation";
import { createClient } from "@/lib/supabase/client";
import AuthBackground from "@/components/AuthBackground";

const input =
  "w-full rounded-lg border border-white/15 bg-white/10 px-3 py-2.5 text-white placeholder-slate-300 outline-none focus:border-violet-400";

export default function LoginPage() {
  const router = useRouter();
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(false);

  async function onSubmit(e: React.FormEvent) {
    e.preventDefault();
    setLoading(true);
    setError("");
    const supabase = createClient();
    const { error } = await supabase.auth.signInWithPassword({ email, password });
    if (error) {
      setError(error.message);
      setLoading(false);
      return;
    }
    router.push("/dashboard");
    router.refresh();
  }

  return (
    <>
      <AuthBackground />
      <main className="flex min-h-screen items-center justify-center p-6">
        <div className="w-full max-w-sm">
          <div className="rounded-2xl border border-white/15 bg-white/10 p-7 shadow-2xl backdrop-blur-xl">
            <div className="mb-5 flex flex-col items-center text-center">
              {/* eslint-disable-next-line @next/next/no-img-element */}
              <img
                src="/sava-logo.jpg"
                alt="SAVA"
                className="h-16 w-16 rounded-2xl shadow-lg ring-1 ring-white/20"
              />
              <h1 className="mt-3 text-xl font-bold">SAVA Technical Institute</h1>
              <p className="mt-1 text-sm text-slate-300">Welcome back — sign in to continue.</p>
            </div>

            <form onSubmit={onSubmit} className="space-y-3">
              <input
                type="email"
                required
                placeholder="Email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                className={input}
              />
              <input
                type="password"
                required
                placeholder="Password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                className={input}
              />
              {error && <p className="text-sm text-red-300">{error}</p>}
              <button
                type="submit"
                disabled={loading}
                className="w-full rounded-lg bg-violet-600 py-2.5 font-semibold shadow-lg shadow-violet-900/40 hover:bg-violet-500 disabled:opacity-60"
              >
                {loading ? "Signing in…" : "Sign in"}
              </button>
            </form>

            <p className="mt-5 text-center text-sm text-slate-300">
              New here?{" "}
              <Link href="/signup" className="font-semibold text-violet-300">
                Create an account
              </Link>
            </p>
          </div>
          <p className="mt-5 text-center text-[11px] uppercase tracking-widest text-slate-400">
            Designed &amp; built by{" "}
            <span className="font-semibold text-slate-300">Aland Hiwa</span>
          </p>
        </div>
      </main>
    </>
  );
}
