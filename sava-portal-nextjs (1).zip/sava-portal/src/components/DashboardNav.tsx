"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";
import { isAdmin, isStaff, roleHome, type Role } from "@/lib/types";

export default function DashboardNav({ role }: { role: Role }) {
  const path = usePathname();
  const links = [
    { href: roleHome[role], label: "Home" },
    { href: "/dashboard/announcements", label: "Announcements" },
    ...(role === "student" ? [{ href: "/dashboard/grades", label: "Grades" }] : []),
    ...(isStaff(role) ? [{ href: "/dashboard/subjects", label: "Subjects" }] : []),
    ...(isAdmin(role) ? [{ href: "/dashboard/people", label: "People" }] : []),
    { href: "/dashboard/profile", label: "Profile" },
  ];
  return (
    <nav className="flex gap-1 overflow-x-auto">
      {links.map((l) => {
        const active = path === l.href || path.startsWith(l.href + "/");
        return (
          <Link
            key={l.href}
            href={l.href}
            className={`whitespace-nowrap rounded-lg px-3 py-1.5 text-sm font-medium transition-colors ${
              active
                ? "bg-violet-600/30 text-violet-200"
                : "text-slate-300 hover:bg-white/5"
            }`}
          >
            {l.label}
          </Link>
        );
      })}
    </nav>
  );
}
